
void hexdump(void *buf, size_t len);
